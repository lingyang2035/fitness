// --- Confirm Dialog ---
let _confirmResolve = null;
function showConfirm(msg) {
    return new Promise((resolve) => {
        _confirmResolve = resolve;
        document.getElementById('confirm-msg').innerText = msg;
        document.getElementById('confirm-dialog').classList.add('active');
    });
}
function _confirmYes() {
    document.getElementById('confirm-dialog').classList.remove('active');
    if (_confirmResolve) { _confirmResolve(true); _confirmResolve = null; }
}
function _confirmNo() {
    document.getElementById('confirm-dialog').classList.remove('active');
    if (_confirmResolve) { _confirmResolve(false); _confirmResolve = null; }
}

let currentTab = 'dashboard';
let _currentUserId = null;

window.onload = async function() {
    try {
        const user = await API.getMe();
        if (user.role !== 'admin') {
            window.location.href = window.APP_PREFIX + '/app';
            return;
        }
        _currentUserId = user.id;
        document.getElementById('user-info').textContent = `${user.avatar_emoji || ''} ${user.display_name}`;
    } catch (e) {
        window.location.href = window.APP_PREFIX + '/login';
        return;
    }
    switchTab('dashboard');
    lucide.createIcons();
};

function switchTab(tab) {
    currentTab = tab;
    ['dashboard', 'users', 'records', 'logs', 'invites'].forEach(t => {
        const btn = document.getElementById('tab-' + t);
        if (t === tab) {
            btn.className = 'flex-1 py-2 rounded-xl text-xs font-semibold bg-indigo-600 text-white transition-all';
        } else {
            btn.className = 'flex-1 py-2 rounded-xl text-xs font-semibold text-indigo-400 transition-all';
        }
    });
    loadTabContent();
}

async function loadTabContent() {
    const area = document.getElementById('content-area');
    area.innerHTML = '<p class="text-center text-zinc-400 py-8">加载中...</p>';

    try {
        switch (currentTab) {
            case 'dashboard': await renderDashboard(area); break;
            case 'users': await renderUsers(area); break;
            case 'records': await renderRecords(area); break;
            case 'logs': await renderLogs(area); break;
            case 'invites': await renderInvites(area); break;
        }
    } catch (e) {
        area.innerHTML = `<p class="text-center text-red-400 py-8">加载失败: ${escapeHtml(e.message)}</p>`;
    }
    lucide.createIcons();
}

// --- Dashboard ---
async function renderDashboard(area) {
    const data = await API.getDashboard();
    area.innerHTML = `
        <div class="grid grid-cols-2 gap-3 mb-4">
            <div class="bg-indigo-50 p-4 rounded-2xl">
                <div class="text-xs text-indigo-400 mb-1">用户总数</div>
                <div class="text-2xl font-bold text-zinc-800">${data.total_users}</div>
            </div>
            <div class="bg-green-50 p-4 rounded-2xl">
                <div class="text-xs text-green-400 mb-1">本周记录</div>
                <div class="text-2xl font-bold text-green-700">${data.records_this_week}</div>
            </div>
            <div class="bg-amber-50 p-4 rounded-2xl">
                <div class="text-xs text-amber-400 mb-1">总记录数</div>
                <div class="text-2xl font-bold text-amber-700">${data.total_records}</div>
            </div>
            <div class="bg-purple-50 p-4 rounded-2xl">
                <div class="text-xs text-purple-400 mb-1">邀请次数</div>
                <div class="text-2xl font-bold text-purple-700">${data.total_invites}</div>
            </div>
        </div>
        <div class="space-y-2">
            <button onclick="switchTab('users')" class="w-full text-left p-3 bg-zinc-50 rounded-xl text-sm font-medium text-zinc-700 hover:bg-indigo-50 transition-colors">👥 管理用户 →</button>
            <button onclick="switchTab('logs')" class="w-full text-left p-3 bg-zinc-50 rounded-xl text-sm font-medium text-zinc-700 hover:bg-indigo-50 transition-colors">📋 查看日志 →</button>
            <button onclick="switchTab('invites')" class="w-full text-left p-3 bg-zinc-50 rounded-xl text-sm font-medium text-zinc-700 hover:bg-indigo-50 transition-colors">🔗 管理邀请 →</button>
        </div>
    `;
}

// --- Users ---
let _userMap = {};
async function renderUsers(area) {
    const res = await API.getAdminUsers();
    const users = res.users || [];
    _userMap = {};
    users.forEach(u => { _userMap[u.id] = u; });

    area.innerHTML = `
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-zinc-800">用户列表 (${users.length})</h3>
            <button onclick="openUserModal()" class="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-indigo-700 transition-colors">+ 添加用户</button>
        </div>
        <div class="space-y-2">
            ${users.map(u => `
                <div class="flex items-center justify-between p-3 bg-zinc-50 rounded-xl">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${u.role === 'admin' ? 'bg-amber-100 text-amber-600' : 'bg-indigo-100 text-indigo-600'}">
                            ${escapeHtml(u.display_name[0])}
                        </div>
                        <div>
                            <div class="text-sm font-bold text-zinc-800">
                                ${escapeHtml(u.display_name)}
                                ${u.role === 'admin' ? '<span class="text-[10px] bg-amber-100 text-amber-600 px-1.5 py-0.5 rounded-full ml-1">管理</span>' : ''}
                                ${!u.is_active ? '<span class="text-[10px] bg-red-100 text-red-500 px-1.5 py-0.5 rounded-full ml-1">已停用</span>' : ''}
                            </div>
                            <div class="text-xs text-zinc-400">@${escapeHtml(u.username)} · ${u.last_login ? '最近登录: ' + u.last_login.slice(0, 10) : '从未登录'}</div>
                        </div>
                    </div>
                    <div class="flex gap-1">
                        <button onclick="openUserModal(${u.id})" class="p-2 text-zinc-400 hover:text-indigo-600">
                            <i data-lucide="edit-2" class="w-4 h-4 pointer-events-none"></i>
                        </button>
                        <button onclick="${u.id !== _currentUserId ? `deleteUser(${u.id})` : `showToast('不能删除自己的账号')`}" class="p-2 ${u.id !== _currentUserId ? 'text-zinc-400 hover:text-red-400' : 'text-zinc-300 cursor-not-allowed'}">
                            <i data-lucide="trash-2" class="w-4 h-4 pointer-events-none"></i>
                        </button>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

async function deleteUser(id) {
    const name = (_userMap[id] && _userMap[id].display_name) || `ID:${id}`;
    if (!(await showConfirm(`确定删除用户「${name}」？\n此操作不可撤销，将同时删除该用户的所有运动记录。`))) return;
    try {
        await API.deactivateUser(id);
        loadTabContent();
        showToast('用户已删除', 'success');
    } catch (e) {
        showToast(e.message);
    }
}

let editingUserId = null;
async function openUserModal(userId = null) {
    editingUserId = userId;
    const modal = document.getElementById('user-modal');
    modal.classList.remove('hidden');

    if (userId) {
        document.getElementById('user-modal-title').textContent = '编辑用户';
        const res = await API.getAdminUsers();
        const user = (res.users || []).find(u => u.id === userId);
        if (user) {
            document.getElementById('edit-user-id').value = user.id;
            document.getElementById('edit-username').value = user.username;
            document.getElementById('edit-display-name').value = user.display_name;
            document.getElementById('edit-role').value = user.role;
            document.getElementById('edit-active').checked = !!user.is_active;
            document.getElementById('edit-password').value = '';
        }
    } else {
        document.getElementById('user-modal-title').textContent = '添加用户';
        document.getElementById('edit-user-id').value = '';
        document.getElementById('edit-username').value = '';
        document.getElementById('edit-display-name').value = '';
        document.getElementById('edit-role').value = 'member';
        document.getElementById('edit-active').checked = true;
        document.getElementById('edit-password').value = '';
    }
}

function closeUserModal() {
    document.getElementById('user-modal').classList.add('hidden');
}

async function submitUserForm(e) {
    e.preventDefault();
    const id = document.getElementById('edit-user-id').value;
    const username = document.getElementById('edit-username').value.trim();
    const displayName = document.getElementById('edit-display-name').value.trim();
    const role = document.getElementById('edit-role').value;
    const isActive = document.getElementById('edit-active').checked ? 1 : 0;
    const password = document.getElementById('edit-password').value;

    try {
        if (id) {
            const data = { display_name: displayName, role, is_active: isActive };
            if (password) {
                if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
                    showToast('密码至少8位，且必须包含数字和字母');
                    return;
                }
                data.new_password = password;
            }
            await API.updateUser(parseInt(id), data);
            showToast('用户已更新', 'success');
        } else {
            if (!password || password.length < 8 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
                showToast('密码至少8位，且必须包含数字和字母');
                return;
            }
            await API.createUser({ username, password, display_name: displayName, role });
            showToast('用户已创建', 'success');
        }
        closeUserModal();
        loadTabContent();
    } catch (e) {
        showToast(e.message);
    }
}

// --- Records ---
async function renderRecords(area) {
    const res = await API.getAdminRecords({ limit: 100 });
    const records = res.records || [];

    area.innerHTML = `
        <h3 class="font-bold text-zinc-800 mb-3">全部运动记录 (${records.length})</h3>
        <div class="space-y-2 max-h-[500px] overflow-y-auto">
            ${records.length === 0 ? '<p class="text-center text-zinc-400 py-4 text-sm">暂无记录</p>' : records.map(r => `
                <div class="flex items-center justify-between p-3 bg-zinc-50 rounded-xl">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center font-bold text-xs">
                            ${(r.user_display_name || '?')[0]}
                        </div>
                        <div>
                            <div class="text-sm font-bold text-zinc-800">${escapeHtml(r.exercise_type)} · ${r.duration_minutes}min</div>
                            <div class="text-xs text-zinc-400">${escapeHtml(r.user_display_name)} · ${r.recorded_at ? r.recorded_at.slice(0, 16) : ''}</div>
                        </div>
                    </div>
                    <button onclick="deleteAdminRecord(${r.id})" class="p-2 text-zinc-300 hover:text-red-400">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </div>
            `).join('')}
        </div>
    `;
}

async function deleteAdminRecord(id) {
    if (!(await showConfirm('确定删除此记录？'))) return;
    try {
        await API.deleteAdminRecord(id);
        loadTabContent();
        showToast('已删除', 'success');
    } catch (e) {
        showToast(e.message);
    }
}

// --- Logs ---
let logsPage = 1;
async function renderLogs(area) {
    const res = await API.getAdminLogs({ page: logsPage, per_page: 20 });
    const logs = res.logs || [];
    const pag = res.pagination || {};

    area.innerHTML = `
        <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-zinc-800">访问日志 (${pag.total || 0})</h3>
        </div>
        <div class="space-y-1 max-h-[500px] overflow-y-auto mb-4">
            ${logs.length === 0 ? '<p class="text-center text-zinc-400 py-4 text-sm">暂无日志</p>' : logs.map(l => `
                <div class="p-2 bg-zinc-50 rounded-lg text-xs">
                    <div class="flex justify-between">
                        <span class="font-medium text-zinc-700">${escapeHtml(l.action)}</span>
                        <span class="text-zinc-400">${l.created_at ? l.created_at.slice(0, 19) : ''}</span>
                    </div>
                    <div class="text-zinc-400 mt-0.5">
                        ${escapeHtml(l.user_display_name || '匿名')} · ${escapeHtml(l.ip_address || '-')}
                    </div>
                </div>
            `).join('')}
        </div>
        <div class="flex justify-between items-center">
            <button onclick="logsPage=Math.max(1,logsPage-1);loadTabContent()" ${logsPage <= 1 ? 'disabled' : ''}
                    class="px-3 py-1.5 bg-indigo-50 rounded-lg text-xs font-medium disabled:opacity-30">上一页</button>
            <span class="text-xs text-zinc-400">${pag.page} / ${pag.total_pages || 1}</span>
            <button onclick="logsPage++;loadTabContent()" ${logsPage >= pag.total_pages ? 'disabled' : ''}
                    class="px-3 py-1.5 bg-indigo-50 rounded-lg text-xs font-medium disabled:opacity-30">下一页</button>
        </div>
    `;
}

// --- Invites ---
async function renderInvites(area) {
    const res = await API.getAdminInvites();
    const invites = res.invites || [];

    area.innerHTML = `
        <div class="flex justify-between items-center mb-3">
            <h3 class="font-bold text-zinc-800">邀请令牌</h3>
            <button onclick="generateAdminInvite()" class="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-indigo-700 transition-colors">+ 生成新邀请</button>
        </div>
        <div id="admin-invite-url-box" class="hidden bg-indigo-50 p-4 rounded-xl mb-4">
            <p class="text-xs text-indigo-400 mb-1">新邀请链接</p>
            <p class="text-sm font-mono text-zinc-800 break-all" id="admin-invite-url-text"></p>
            <button onclick="copyAdminInviteUrl()" class="mt-2 w-full bg-indigo-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-indigo-700 transition-colors">复制链接</button>
        </div>
        <div class="space-y-2">
            ${invites.length === 0 ? '<p class="text-center text-zinc-400 py-4 text-sm">暂无邀请</p>' : invites.map(inv => {
                const status = inv.is_used ? '已用' : (inv.expires_at && inv.expires_at < new Date().toISOString() ? '已过期' : '有效');
                const color = status === '有效' ? 'text-green-600' : 'text-zinc-400';
                return `
                    <div class="flex items-center justify-between p-3 bg-zinc-50 rounded-xl">
                        <div>
                            <div class="text-sm font-mono text-zinc-700">${inv.token.slice(0, 12)}...</div>
                            <div class="text-xs text-zinc-400">创建者: ${escapeHtml(inv.creator_name || 'N/A')} · <span class="${color}">${status}</span></div>
                        </div>
                        ${!inv.is_used ? `<button onclick="revokeAdminInvite(${inv.id})" class="text-xs text-red-400 hover:text-red-600 font-medium">撤销</button>` : ''}
                    </div>
                `;
            }).join('')}
        </div>
    `;
}

async function generateAdminInvite() {
    try {
        const res = await API.createInviteToken({ max_uses: 10, expires_in_days: 30 });
        const url = window.location.origin + window.APP_PREFIX + '/join?token=' + res.token;
        document.getElementById('admin-invite-url-text').textContent = url;
        document.getElementById('admin-invite-url-box').classList.remove('hidden');
        loadTabContent();
    } catch (e) {
        showToast(e.message);
    }
}

function copyAdminInviteUrl() {
    const text = document.getElementById('admin-invite-url-text').textContent;
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => showToast('已复制', 'success'));
    } else {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('已复制', 'success');
    }
}

async function revokeAdminInvite(id) {
    if (!(await showConfirm('确定撤销此邀请？'))) return;
    try {
        await API.revokeAdminInvite(id);
        loadTabContent();
        showToast('已撤销', 'success');
    } catch (e) {
        showToast(e.message);
    }
}
